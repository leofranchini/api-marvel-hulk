export interface criadoressType{
    nome: String,
    funcao: String,
}