export interface comicsType{
    titulo: String,
    descricao: String,
    dataPublicacao: String,
    capa: String
}