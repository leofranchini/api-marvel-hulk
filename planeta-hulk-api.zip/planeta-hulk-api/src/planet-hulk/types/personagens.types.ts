export interface personagensTypes{
    nome: String,
    descricao: String,
    imagemurl: String,
}